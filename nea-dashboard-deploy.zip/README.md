# NEA Dashboard

Tableau de bord de pilotage commercial pour NEA Madagascar (Groupe Axian).

## Vue d'ensemble

Dashboard web statique alimenté par un fichier Excel mère unique (PILOTAGE_NEA_2026.xlsx) hébergé sur SharePoint Axian.

5 sections principales :
- Cockpit DG : vue synthétique du parc et du pipe avec alertes automatiques
- Pipeline : vue Kanban des deals en cours (HOT / À RELANCER / STANDBY)
- Actions hebdo : suivi opérationnel de la semaine en cours
- Projets : pilotage des chantiers en travaux (retards et clôtures PV)
- Sites : parc installé avec carte interactive et alertes exonération

## Mise à jour des données

Le fichier de données est intégré directement dans `index.html` lors de la régénération.

**Workflow hebdomadaire :**
1. Mise à jour du fichier mère PILOTAGE_NEA_2026.xlsx (au fil de l'eau pendant la semaine)
2. Lundi matin : régénération du dashboard depuis le fichier mère
3. Push GitHub : le dashboard public est mis à jour automatiquement

## Architecture

- HTML standalone (un seul fichier)
- Aucun backend, hébergement GitHub Pages
- Tailwind utilities via classes custom CSS
- Chart.js pour les graphiques
- Leaflet pour la carte interactive
- Données embarquées dans le fichier (JSON inline)

## Phase 2 (prévue)

Connexion Microsoft Graph API pour édition live depuis le dashboard avec écriture vers Excel SharePoint.

## Contact

Valentin Léomant — Responsable Commercial & Communication, NEA Madagascar
