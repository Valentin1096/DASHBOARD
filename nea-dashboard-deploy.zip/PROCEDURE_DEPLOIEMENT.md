# Déploiement NEA Dashboard sur GitHub Pages

Procédure pour mettre en ligne le dashboard et obtenir un lien partageable avec Loïc et Axel.

Temps estimé : 10 minutes la première fois.

---

## Étape 1 — Créer un compte GitHub si nécessaire

Si tu as déjà un compte GitHub personnel ou pro, passe à l'étape 2.

Sinon : aller sur https://github.com/signup et créer un compte avec ton adresse mail (perso ou Axian).

Recommandation : utilise une adresse pro si tu peux, le compte sera lié au projet d'entreprise.

---

## Étape 2 — Créer le repository

1. Aller sur https://github.com/new
2. Renseigner :
   - Repository name : `nea-dashboard`
   - Description : `Dashboard pilotage commercial NEA Madagascar`
   - Visibilité : **Private** (important pour les données NEA)
   - Cocher "Add a README file"
3. Cliquer "Create repository"

Tu arrives sur la page du repo, vide pour l'instant.

---

## Étape 3 — Uploader les fichiers

Le plus simple : interface web GitHub (pas besoin de Git en ligne de commande).

1. Sur la page du repo, cliquer sur le lien "uploading an existing file" (texte gris au milieu de la page) ou directement "Add file" → "Upload files"
2. Glisser-déposer les 3 fichiers du dossier `nea-dashboard-deploy` que je t'ai préparé :
   - `index.html` (le dashboard)
   - `README.md`
   - `.gitignore`
3. Tout en bas de la page, dans "Commit changes" :
   - Laisser le titre "Add files via upload"
   - Cliquer "Commit changes"

Les fichiers sont maintenant sur GitHub.

---

## Étape 4 — Activer GitHub Pages

C'est l'étape qui rend le dashboard accessible via une URL publique.

1. Dans ton repo, cliquer sur l'onglet "Settings" (en haut à droite)
2. Dans le menu de gauche, cliquer sur "Pages"
3. Section "Build and deployment" :
   - Source : sélectionner "Deploy from a branch"
   - Branch : sélectionner `main` et `/ (root)`
   - Cliquer "Save"
4. Attendre 1-2 minutes, GitHub construit le site

---

## Étape 5 — Récupérer le lien partageable

Sur la même page Settings → Pages, tu verras apparaître en haut un bandeau vert :

```
Your site is live at https://[ton-username].github.io/nea-dashboard/
```

C'est ce lien que tu envoies à Loïc et Axel.

---

## Important — Repo privé et accès limité

**Problème** : un repo privé avec GitHub Pages activé est accessible publiquement par défaut (l'URL est devinable mais peu probable d'être trouvée par hasard).

Pour vraiment restreindre l'accès :
- **Option A — Garder le repo privé tel quel** : l'URL reste partageable, Loïc/Axel n'ont besoin de rien d'autre que du lien. Mais quiconque connaît l'URL peut accéder au dashboard. Acceptable pour un POC partagé entre collègues.
- **Option B — Restriction par GitHub** : nécessite GitHub Pro/Enterprise. Permet de limiter l'accès à des utilisateurs GitHub authentifiés.
- **Option C — Mot de passe basique** : ajouter une page d'accueil avec un mot de passe avant d'accéder au dashboard (je peux te le préparer si besoin).

Pour démarrer et faire la démo à Loïc/Axel cette semaine, l'Option A suffit largement.

---

## Mises à jour ultérieures

Pour mettre à jour le dashboard avec de nouvelles données :

1. Tu régénères `index.html` côté Claude depuis le fichier mère
2. Tu reviens dans ton repo GitHub
3. Tu cliques sur le fichier `index.html` existant
4. Tu cliques sur l'icône crayon (Edit this file) ou tu fais "Add file" → "Upload files" pour le remplacer
5. Tu commits

GitHub Pages se régénère automatiquement en 1-2 minutes.

---

## Lien à transmettre

Une fois l'étape 5 faite, ton URL ressemblera à :

```
https://valentinleomant.github.io/nea-dashboard/
```

Email type pour Loïc et Axel :

> Bonjour Loïc, Bonjour Axel,
>
> Voici le lien vers la première version du tableau de bord NEA :
> https://[ton-username].github.io/nea-dashboard/
>
> 5 sections : vue de pilotage globale (Cockpit DG), pipeline commercial en mode Kanban, actions de la semaine, projets travaux et parc installé.
>
> Cette version est alimentée par le fichier mère PILOTAGE_NEA_2026.xlsx que je maintiens sur SharePoint. La mise à jour se fera de manière hebdomadaire dans cette première phase. Une connexion temps réel via Microsoft Graph API est prévue dans une seconde phase.
>
> N'hésitez pas à me faire vos retours, je suis preneur.
>
> Valentin

---

## Si problème

GitHub Pages prend parfois 5 minutes à se déployer la première fois. Si l'URL renvoie une erreur 404, attendre quelques minutes et rafraîchir.

Si après 10 minutes ça ne marche toujours pas :
- Vérifier dans Settings → Pages que la branche est bien `main` (pas `master`)
- Vérifier qu'il y a bien un fichier `index.html` à la racine du repo
- Vérifier que les fichiers ont bien été commités (onglet "Code" du repo)
